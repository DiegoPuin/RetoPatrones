package Reto_20162020093_20162020443;
/**
 *
 * @author Julian Sanchez 
 * @author Diego Puin
 */
public interface VisitorInterface {
	public double visit(NonCaliforniaOrder nco);

	public double visit(CaliforniaOrder co);

	public double visit(OverseasOrder oo);

	public double visit(ColombianOrder colo);
}