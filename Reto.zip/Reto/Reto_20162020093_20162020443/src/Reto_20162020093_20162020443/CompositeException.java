package Reto_20162020093_20162020443;

import java.util.*;
/**
 *
 * @author Julian Sanchez 
 * @author Diego Puin
 */
public class CompositeException extends Exception {

  public CompositeException(String msg) {
    super(msg);
  }
} // End of class

